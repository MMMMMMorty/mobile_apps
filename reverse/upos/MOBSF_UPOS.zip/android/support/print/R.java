package android.support.print;
/* loaded from: classes2.dex */
public final class R {
    private R() {
    }
}
