package android.support.v7.view;
/* loaded from: classes.dex */
public interface CollapsibleActionView {
    void onActionViewCollapsed();

    void onActionViewExpanded();
}
