package android.support.v4.view;

import android.view.View;
/* loaded from: classes.dex */
public interface ViewPropertyAnimatorUpdateListener {
    void onAnimationUpdate(View view);
}
